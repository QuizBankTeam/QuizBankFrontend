package com.example.cameratest.models

data class Message(
    val message: String,
    val isFromSender: Boolean,
)